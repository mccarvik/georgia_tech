def HW0(A: tuple[int, ...]) -> tuple[int, list[int]]:
    pass
